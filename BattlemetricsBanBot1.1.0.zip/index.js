const Discord = require('discord.js');
const fetch = require('node-fetch');
const fs = require('fs');
const moment = require('moment');
const config = require('./config.json');

config.ORGANIZATIONS.forEach(org => {

    const client = new Discord.Client({
        intents: [
            'GUILDS',
            'DIRECT_MESSAGES',
            'GUILD_MESSAGES',
            'GUILD_MEMBERS'
        ],
        partials: ['MESSAGE', 'CHANNEL']
    });

    client.on('ready', () => {
        console.log(`\n------ [ BOT IS ONLINE ] ------\nLogged in as: ${client.user.tag}\nMade by: Amino#4229\nSupport Discord: discord.gg/RVePam7pd7\n-------------------------------`);
        let check = -1;
        let theHeaders = { 'Authorization': `Bearer ${org.BATTLEMETRICS_API_KEY}` };
        fetch(`https://api.battlemetrics.com/bans?filter[organization]=${org.ORGANIZATION_ID}&page[size]=1`, { method: "GET", headers: theHeaders }).then(res => res.json()).then(response => {
            if(!response.errors) {
                changeBotStatus(response);
                setInterval(() => {
                    fetch(`https://api.battlemetrics.com/bans?filter[organization]=${org.ORGANIZATION_ID}&page[size]=10`, { method: "GET", headers: theHeaders }).then(res => res.json()).then(response => {
                        changeBotStatus(response);
                        if(!response.errors) {
                            check++;
                            response.data.forEach(ban => {
                                if(ban.type == "ban") {
                                    const banInfo = {};
                                    const dateFilter = ban.attributes.timestamp.split("T");
                                    const banTime = moment(dateFilter[0] + " " + dateFilter[1], "YYYY-MM-D HH:mm:ss").valueOf();
                                    banInfo.timestamp = `<t:${banTime/1000}> | <t:${banTime/1000}:R>`;
                                    banInfo.reason = ban.attributes.reason;
                                    if(ban.attributes.expires == null || ban.attributes.expires.includes('1970') || ban.attributes.expires.includes('1969')) {
                                        banInfo.expires = "Perm";
                                    } else {
                                        const dateFilter1 = ban.attributes.expires.split("T");
                                        const banTime1 = moment(dateFilter1[0] + " " + dateFilter1[1], "YYYY-MM-D HH:mm:ss").valueOf();
                                        banInfo.expires = `<t:${banTime1/1000}> | <t:${banTime1/1000}:R>`
                                    }
                                    let bannedPlayer = ban.attributes.identifiers.find(identifier => identifier.type == "steamID");
                                    banInfo.steamID = bannedPlayer.identifier;
                                    banInfo.username = bannedPlayer.metadata.profile.personaname;
                                    banInfo.logo = bannedPlayer.metadata.profile.avatarfull;
                                    banInfo.note = ban.attributes.note;
                                    if(check == 0) {

                                    } else {
                                        fs.access(`./storedData/${ban.id}.txt`, fs.constants.F_OK, (err) => {
                                            if(!err) {

                                            } else {

                                                let runEmbed = {
                                                        EMBED_FORMAT: {
                                                                "COLOR": "",
                                                                "AUTHOR": {
                                                                    "TEXT": "",
                                                                    "IMAGE": "",
                                                                    "URL": ""
                                                                },
                                                                "DESCRIPTION": "",
                                                                "SMALL_IMAGE": "",
                                                                "LARGE_IMAGE": "",
                                                                "FOOTER": {
                                                                    "IMAGE": "",
                                                                    "TEXT": "",
                                                                    "SET_TIMESTAMP": true
                                                                }
                                                            }
                                                        };
                                                        let runEmbed2 = {
                                                            EMBED_FORMAT: {
                                                                    "COLOR": "",
                                                                    "AUTHOR": {
                                                                        "TEXT": "",
                                                                        "IMAGE": "",
                                                                        "URL": ""
                                                                    },
                                                                    "DESCRIPTION": "",
                                                                    "SMALL_IMAGE": "",
                                                                    "LARGE_IMAGE": "",
                                                                    "FOOTER": {
                                                                        "IMAGE": "",
                                                                        "TEXT": "",
                                                                        "SET_TIMESTAMP": true
                                                                    }
                                                                }
                                                            };
                                                runEmbed.EMBED_FORMAT.AUTHOR.TEXT = org.EMBED_FORMAT.AUTHOR.TEXT.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed.EMBED_FORMAT.AUTHOR.TEXT = runEmbed.EMBED_FORMAT.AUTHOR.TEXT.replace(/{serverName}/gi, org.ORGANIZATION_NAME);
                                                runEmbed.EMBED_FORMAT.AUTHOR.TEXT = runEmbed.EMBED_FORMAT.AUTHOR.TEXT.replace(/{banDate}/gi, banInfo.timestamp);
                                                runEmbed.EMBED_FORMAT.AUTHOR.TEXT = runEmbed.EMBED_FORMAT.AUTHOR.TEXT.replace(/{expiresDate}/gi, banInfo.expires);
                                                runEmbed.EMBED_FORMAT.AUTHOR.TEXT = runEmbed.EMBED_FORMAT.AUTHOR.TEXT.replace(/{username}/gi, banInfo.username);
                                                runEmbed.EMBED_FORMAT.AUTHOR.TEXT = runEmbed.EMBED_FORMAT.AUTHOR.TEXT.replace(/{banReason}/gi, banInfo.reason);
                                                runEmbed.EMBED_FORMAT.AUTHOR.URL = org.EMBED_FORMAT.AUTHOR.URL.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed.EMBED_FORMAT.AUTHOR.IMAGE = org.EMBED_FORMAT.AUTHOR.IMAGE.replace(/{playerLogo}/gi, banInfo.logo);

                                                runEmbed.EMBED_FORMAT.SMALL_IMAGE = org.EMBED_FORMAT.SMALL_IMAGE.replace(/{playerLogo}/gi, banInfo.logo);
                                                runEmbed.EMBED_FORMAT.LARGE_IMAGE = org.EMBED_FORMAT.LARGE_IMAGE.replace(/{playerLogo}/gi, banInfo.logo);

                                                runEmbed.EMBED_FORMAT.DESCRIPTION = org.EMBED_FORMAT.DESCRIPTION.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed.EMBED_FORMAT.DESCRIPTION = runEmbed.EMBED_FORMAT.DESCRIPTION.replace(/{banDate}/gi, banInfo.timestamp);
                                                runEmbed.EMBED_FORMAT.DESCRIPTION = runEmbed.EMBED_FORMAT.DESCRIPTION.replace(/{expiresDate}/gi, banInfo.expires);
                                                runEmbed.EMBED_FORMAT.DESCRIPTION = runEmbed.EMBED_FORMAT.DESCRIPTION.replace(/{username}/gi, banInfo.username);
                                                runEmbed.EMBED_FORMAT.DESCRIPTION = runEmbed.EMBED_FORMAT.DESCRIPTION.replace(/{banNote}/gi, banInfo.note);
                                                runEmbed.EMBED_FORMAT.DESCRIPTION = runEmbed.EMBED_FORMAT.DESCRIPTION.replace(/{banReason}/gi, banInfo.reason);

                                                runEmbed.EMBED_FORMAT.FOOTER.TEXT = org.EMBED_FORMAT.FOOTER.TEXT.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed.EMBED_FORMAT.FOOTER.TEXT = runEmbed.EMBED_FORMAT.FOOTER.TEXT.replace(/{banDate}/gi, banInfo.timestamp);
                                                runEmbed.EMBED_FORMAT.FOOTER.TEXT = runEmbed.EMBED_FORMAT.FOOTER.TEXT.replace(/{expiresDate}/gi, banInfo.expires);
                                                runEmbed.EMBED_FORMAT.FOOTER.TEXT = runEmbed.EMBED_FORMAT.FOOTER.TEXT.replace(/{username}/gi, banInfo.username);
                                                runEmbed.EMBED_FORMAT.FOOTER.TEXT = runEmbed.EMBED_FORMAT.FOOTER.TEXT.replace(/{banReason}/gi, banInfo.reason);
                                                runEmbed.EMBED_FORMAT.FOOTER.IMAGE = org.EMBED_FORMAT.FOOTER.IMAGE.replace(/{playerLogo}/gi, banInfo.logo);

                                                runEmbed2.EMBED_FORMAT.AUTHOR.TEXT = org.STAFF_EMBED_FORMAT.AUTHOR.TEXT.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.TEXT = runEmbed2.EMBED_FORMAT.AUTHOR.TEXT.replace(/{serverName}/gi, org.ORGANIZATION_NAME);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.TEXT = runEmbed2.EMBED_FORMAT.AUTHOR.TEXT.replace(/{banDate}/gi, banInfo.timestamp);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.TEXT = runEmbed2.EMBED_FORMAT.AUTHOR.TEXT.replace(/{expiresDate}/gi, banInfo.expires);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.TEXT = runEmbed2.EMBED_FORMAT.AUTHOR.TEXT.replace(/{username}/gi, banInfo.username);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.TEXT = runEmbed2.EMBED_FORMAT.AUTHOR.TEXT.replace(/{banReason}/gi, banInfo.reason);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.URL = org.STAFF_EMBED_FORMAT.AUTHOR.URL.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed2.EMBED_FORMAT.AUTHOR.IMAGE = org.STAFF_EMBED_FORMAT.AUTHOR.IMAGE.replace(/{playerLogo}/gi, banInfo.logo);

                                                runEmbed2.EMBED_FORMAT.SMALL_IMAGE = org.STAFF_EMBED_FORMAT.SMALL_IMAGE.replace(/{playerLogo}/gi, banInfo.logo);
                                                runEmbed2.EMBED_FORMAT.LARGE_IMAGE = org.STAFF_EMBED_FORMAT.LARGE_IMAGE.replace(/{playerLogo}/gi, banInfo.logo);

                                                runEmbed2.EMBED_FORMAT.DESCRIPTION = org.STAFF_EMBED_FORMAT.DESCRIPTION.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed2.EMBED_FORMAT.DESCRIPTION = runEmbed2.EMBED_FORMAT.DESCRIPTION.replace(/{banDate}/gi, banInfo.timestamp);
                                                runEmbed2.EMBED_FORMAT.DESCRIPTION = runEmbed2.EMBED_FORMAT.DESCRIPTION.replace(/{expiresDate}/gi, banInfo.expires);
                                                runEmbed2.EMBED_FORMAT.DESCRIPTION = runEmbed2.EMBED_FORMAT.DESCRIPTION.replace(/{username}/gi, banInfo.username);
                                                runEmbed2.EMBED_FORMAT.DESCRIPTION = runEmbed2.EMBED_FORMAT.DESCRIPTION.replace(/{banNote}/gi, banInfo.note);
                                                runEmbed2.EMBED_FORMAT.DESCRIPTION = runEmbed2.EMBED_FORMAT.DESCRIPTION.replace(/{banReason}/gi, banInfo.reason);

                                                runEmbed2.EMBED_FORMAT.FOOTER.TEXT = org.STAFF_EMBED_FORMAT.FOOTER.TEXT.replace(/{steamID}/gi, banInfo.steamID);
                                                runEmbed2.EMBED_FORMAT.FOOTER.TEXT = runEmbed2.EMBED_FORMAT.FOOTER.TEXT.replace(/{banDate}/gi, banInfo.timestamp);
                                                runEmbed2.EMBED_FORMAT.FOOTER.TEXT = runEmbed2.EMBED_FORMAT.FOOTER.TEXT.replace(/{expiresDate}/gi, banInfo.expires);
                                                runEmbed2.EMBED_FORMAT.FOOTER.TEXT = runEmbed2.EMBED_FORMAT.FOOTER.TEXT.replace(/{username}/gi, banInfo.username);
                                                runEmbed2.EMBED_FORMAT.FOOTER.TEXT = runEmbed2.EMBED_FORMAT.FOOTER.TEXT.replace(/{banReason}/gi, banInfo.reason);
                                                runEmbed2.EMBED_FORMAT.FOOTER.IMAGE = org.STAFF_EMBED_FORMAT.FOOTER.IMAGE.replace(/{playerLogo}/gi, banInfo.logo);

                                                let embed = new Discord.MessageEmbed();

                                                if(org.EMBED_FORMAT.COLOR) embed.setColor(org.EMBED_FORMAT.COLOR);
                                                if(org.EMBED_FORMAT.AUTHOR.TEXT) embed.setAuthor({ name: runEmbed.EMBED_FORMAT.AUTHOR.TEXT, url: runEmbed.EMBED_FORMAT.AUTHOR.URL, iconURL: runEmbed.EMBED_FORMAT.AUTHOR.IMAGE });
                                                if(org.EMBED_FORMAT.DESCRIPTION) embed.setDescription(runEmbed.EMBED_FORMAT.DESCRIPTION);
                                                if(org.EMBED_FORMAT.SMALL_IMAGE) embed.setThumbnail(runEmbed.EMBED_FORMAT.SMALL_IMAGE);
                                                if(org.EMBED_FORMAT.LARGE_IMAGE) embed.setImage(runEmbed.EMBED_FORMAT.LARGE_IMAGE);
                                                if(org.EMBED_FORMAT.FOOTER.TEXT) embed.setFooter({ text: runEmbed.EMBED_FORMAT.FOOTER.TEXT, iconURL: runEmbed.EMBED_FORMAT.FOOTER.IMAGE });
                                                if(org.EMBED_FORMAT.FOOTER.SET_TIMESTAMP) embed.setTimestamp();

                                                let embed2 = new Discord.MessageEmbed();

                                                if(org.STAFF_EMBED_FORMAT.COLOR) embed2.setColor(org.STAFF_EMBED_FORMAT.COLOR);
                                                if(org.STAFF_EMBED_FORMAT.AUTHOR.TEXT) embed2.setAuthor({ name: runEmbed2.EMBED_FORMAT.AUTHOR.TEXT, url: runEmbed.EMBED_FORMAT.AUTHOR.URL, iconURL: runEmbed.EMBED_FORMAT.AUTHOR.IMAGE });
                                                if(org.STAFF_EMBED_FORMAT.DESCRIPTION) embed2.setDescription(runEmbed2.EMBED_FORMAT.DESCRIPTION);
                                                if(org.STAFF_EMBED_FORMAT.SMALL_IMAGE) embed2.setThumbnail(runEmbed2.EMBED_FORMAT.SMALL_IMAGE);
                                                if(org.STAFF_EMBED_FORMAT.LARGE_IMAGE) embed2.setImage(runEmbed2.EMBED_FORMAT.LARGE_IMAGE);
                                                if(org.STAFF_EMBED_FORMAT.FOOTER.TEXT) embed2.setFooter({ text: runEmbed2.EMBED_FORMAT.FOOTER.TEXT, iconURL: runEmbed.EMBED_FORMAT.FOOTER.IMAGE });
                                                if(org.STAFF_EMBED_FORMAT.FOOTER.SET_TIMESTAMP) embed2.setTimestamp();

                                                org['LOG_BAN_WEBHOOK(S)'].forEach(webHook => {
                                                    let hook = new Discord.WebhookClient({ url: webHook });

                                                    hook.send({ embeds: [embed] });
                                                });

                                                org['STAFF_BAN_LOG_WEBHOOK(S)'].forEach(webHook => {
                                                    let hook = new Discord.WebhookClient({ url: webHook });

                                                    hook.send({ embeds: [embed2] });
                                                });

                                                fs.writeFile(`./storedData/${ban.id}.txt`, banInfo.toString(), (err) => {
                                                    if(err) throw err;
                                                });
                                            }
                                        });
                                    }
                                } 
                            });
                        } else {
                            console.log("There was an error while checking for new bans.");
                        }
                    });
                }, 30000);
            } else {
                console.log("There was an error with the battlemetrics API call.\nPlease make sure you have a valid organization ID and battlemetrics API key.");
            }
        });
    });


    function changeBotStatus(response) {
        let formatMessage = org.BOT_STATUS.MESSAGE.replace(/{banCount}/gi, response.meta.total);
        client.user.setPresence({ activities: [{ type: `${org.BOT_STATUS['TYPE (PLAYING, STREAMING, LISTENING, WATCHING)']}`, name: formatMessage }], status: org.BOT_STATUS['STATUS (online, dnd, invisible, idle)'] });
    }


    client.login(org.BOT_TOKEN);
});

