    # Setup guide #

    Fill out the config.json file.

    HOW TO GET YOUR BOT TOKEN
    https://www.writebots.com/discord-bot-token/

    ORG_ID
    To get your organization ID, go to https://www.battlemetrics.com/rcon/orgs sekect your organization
    At the end of the URL you will see a few numbers, select those and that is your organization ID

    BATTLEMETRICS_API_KEY
    https://www.battlemetrics.com/developers

  # The site that I recommend for hosting is... #
  - https://pebblehost.com/
    > It gives you everything that you need for only $3 a month. 
    > It gives you 1024MB of RAM which is way more than enough RAM to run this bot.
    > 1 Free MySQL database
    > Automaic backups every 7 days
    > ETC*
  
  #  --- [ HOSTED SETUP ] ---  #

    - A host system that offers Node.js 16.6 and above is required
    - All you need to do is extract the files to the file manager section of your hosting
    - Fill out the config
    - Set the startup file to index.js (Most hosts have this set by default)

  #  --- [ LOCAL HOSTING SETUP ] ---  #

    - Fill out the configs
    - Make sure you have node installed. It must be version 16.6 and above.
    - Open a command prompt and do cd filePath 
    - Example, for me to get into my folder I'd do cd C:\Users\PC\Desktop\BattlemetricsBans
    - Then run node index.js

  #  --- [ SUPPORT ] ---  #

    Questions, comments, concerns join my support server! discord.gg/RVePam7pd7
    - Amino#4229